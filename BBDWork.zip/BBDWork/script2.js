const canvas = document.getElementById('mazeCanvas');
const pen = canvas.getContext('2d');

const width = canvas.width;
const height = canvas.height;
let cellSize = 40;

const playerRadius = cellSize / 2 - 5;

const cols = Math.floor(width / cellSize);
const rows = Math.floor(height / cellSize);
const player1 = {
	"x": 0,
	"y": 0,
	color: "red",
};

document.querySelector('.startbtn').addEventListener('click', function () {
	resetPlayerPos();
	clearScreen();
	drawPlayer(player1);  // Only draw the player ball
	displayHidden();
});
document.querySelector('#btnUpdate').addEventListener('click', function () {
   UpdatePlayerPos();
	clearScreen();
	drawPlayer(player1);  // Only draw the player ball
	displayHidden();
	
});

function UpdatePlayerPos() {
/*	player1.x = 1;
	player1.y = 1;
	clearScreen();
	drawPlayer(player1);  // Only draw the player ball
	displayHidden();*/
     document.getElementById('fileInput').addEventListener('change', function(event) {
    const file = event.target.files[0];
    if (!file) {
        return;
    }

    const reader = new FileReader();
    reader.onload = function(e) {
        const contents = e.target.result;
        const lines = contents.split('\n');
        if (lines.length < 2) {
            alert('File does not contain enough lines');
            return;
        }

        const x = parseFloat(lines[0].trim());
        const y = parseFloat(lines[1].trim());

        document.getElementById('output').textContent = `x: ${x}, y: ${y}`;
    };

    reader.onerror = function() {
        alert('Error reading file');
    };

    reader.readAsText(file);

});
clearScreen();
	drawPlayer(player1);  // Only draw the player ball
	displayHidden();
} 

document.addEventListener('DOMContentLoaded', function () {
	const startButton = document.querySelector('.startbtn');
	function stopBlinking() {
		startButton.classList.remove("blink");
	}
	startButton.classList.add("blink");
	startButton.addEventListener("click", stopBlinking);
});

function resetPlayerPos() {
	player1.x = 0;
	player1.y = 0;
}

function clearScreen() {
	pen.canvas.width = pen.canvas.width;
}

function displayHidden() {
	document.getElementsByClassName('msgbox')[0].style.visibility = "hidden";
}

function drawPlayer(player) {
	const x = player.x * cellSize + cellSize / 2;
	const y = player.y * cellSize + cellSize / 2;

	pen.beginPath();
	pen.arc(x, y, playerRadius, 0, 2 * Math.PI);
	pen.fillStyle = player.color;
	pen.fill();
}

// Initial setup and draw
/* resetPlayerPos();
clearScreen();
drawPlayer(player1);
 */